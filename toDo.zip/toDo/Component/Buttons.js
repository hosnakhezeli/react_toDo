import React, { useState } from 'react';
import Mul from './../image/Mul.png';
import Tic from './../image/Tic.png';

const Buttons = (props) => {

    const [BgColor, setBgColor] = useState("#f1e9e9");

    const handleColor = () => {
        setBgColor("#fae969");
        props.changeColor(props.liId);
    };

    return (
        <div>
            <button onClick={(props) => {
                let toDO = props.val;
                toDO.splice(props.Index, 1);

            }}>
                <img src={Mul} />
            </button>
            <button onClick={handleColor} style={{ backgroundColor: BgColor }}>
                <img src={Tic} />
            </button>
        </div>
    );
};


export default Buttons;