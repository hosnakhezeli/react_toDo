import React, { Component } from "react";
import Plus from "./../image/Plus.jpg";
import "./../styles/index.css";
import Title from "./Title";
import Buttons from "./Buttons";


class Test extends Component {
  constructor(props) {
    super(props);
    this.state = {
      toDo: [],
      text: " ",
      BgColor: "#f1e9e9"
    };
  }

  handleLiColor(Id) {
    document.getElementById(Id).style.backgroundColor = "#00ff00";
  }

  render() {
    return (
      <div className="tdl-body-warp">
        <Title countTitle={this.state.toDo.length} />
        <div className="tdl-warp">
          <input
            onChange={(e) => {
              this.setState({
                text: e.target.value,
              });
            }}
            placeholder="کار جدید"
          />
          <button
            onClick={() => {
              if (!this.state.text) {
                alert("متن نمیتواند خالی باشد!");
                return;
              }
              /*let prev = this.state.toDo;
                        prev.push(this.state.text);
                        this.setState ({
                            toDo : prev,
                        })*/
              this.setState({
                toDo: [this.state.text, ...this.state.toDo],
              });
            }}
          >
            <img src={Plus} />
          </button>
        </div>
        <ul>
          {this.state.toDo.map((val, Index) => (
            <li id={"item" + Index} key={Index} style={{ backgroundColor: this.state.BgColor }}>
              {val}
              <Buttons
                val={this.state.text}
                Index={this.state.toDo}
                BgColor={this.state.BgColor}
                liId={"item" + Index}
                changeColor={this.handleLiColor} />
            </li>
          ))}
        </ul>
      </div>
    );
  }
}

export default Test;
