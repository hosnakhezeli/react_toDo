import React from "react";
import "./../styles/index.css";

const Title = (props)=> {

    return(
       <div>
           <div>
               <h3 className="LabeL">لیست کارها ({props.countTitle})</h3>
           </div>
       </div>
    );
};

export default Title;