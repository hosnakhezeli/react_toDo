import Test from "./Component/Test";

function App() {
  return (
    <Test/>
  );
}

export default App;
